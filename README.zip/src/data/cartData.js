export const initialCart = [
  {
    id: 1,
    name: "Jyotish-Vigyan-Magazine-By-KM-Sinha-July-2023",
    price: 500,
    qty: 2,
    image: "https://kundaliexpert.b-cdn.net/Asset/682-34da8c8d-a5b4-4932-b666-719241b5c1bf.webp"
  },
  {
    id: 2,
    name: "Jyotish-Vigyan-Magazine-By-KM-Sinha-July-2023",
    price: 500,
    qty: 2,
    image: "https://kundaliexpert.b-cdn.net/Asset/682-34da8c8d-a5b4-4932-b666-719241b5c1bf.webp"
  },
  {
    id: 3,
    name: "Jyotish-Vigyan-Magazine-By-KM-Sinha-July-2023",
    price: 500,
    qty: 2,
    image: "https://kundaliexpert.b-cdn.net/Asset/682-34da8c8d-a5b4-4932-b666-719241b5c1bf.webp"
  }
]

export const initialAddresses = [
    "Default Address: 123 Street, City",
    "Default Address: 123 Street, City",
    "Default Address: 123 Street, City"
]