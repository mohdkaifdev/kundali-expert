import React from "react";

export default function WelcomeHeader() {
  return (
    <>
      <h2 className="mrn_clr">Welcome!</h2>
      <p className="gray_clr">You have successfully registered your account!</p>
    </>
  );
}