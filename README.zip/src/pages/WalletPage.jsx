import react from "react";
import WalletPage from "../components/wallet/WalletPage";
const Wallet = () => {
    return(
        <>
            <WalletPage/>
        </>
    );
}
export default Wallet;