import React from "react";
import WelcomePage from "../../components/auth/WelcomePage";
const Welcome = () => {
    return(
        <>
            <WelcomePage/>
        </>
    );
}
export default Welcome;