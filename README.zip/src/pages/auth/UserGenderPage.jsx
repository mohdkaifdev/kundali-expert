import React from "react";
import UserGenderPage from "../../components/auth/UserGenderPage";

const UserGender = () => {
    return(
        <>
            <UserGenderPage/>
        </>
    )
}
export default UserGender;