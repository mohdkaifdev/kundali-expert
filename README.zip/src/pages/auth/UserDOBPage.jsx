import React from "react";
import UserDOBPage from "../../components/auth/UserDOBPage";
const UserDOB = () => {
    return(
        <>
            <UserDOBPage/>
        </>
    )
}
export default UserDOB;