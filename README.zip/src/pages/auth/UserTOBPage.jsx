import React from "react";
import UserTOBPage from "../../components/auth/UserTOBPage";
const UserTOB = () => {
    return(
        <>
            <UserTOBPage/>
        </>
    )
}
export default UserTOB;