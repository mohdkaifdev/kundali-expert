import React from "react";
import UserPlacePage from "../../components/auth/UserPlacePage";
const UserPlace = () => {
    return(
        <>
            <UserPlacePage />
        </>
    )
}
export default UserPlace;