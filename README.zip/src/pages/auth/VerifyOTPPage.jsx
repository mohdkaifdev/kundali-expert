import React from "react";
import VerifyOTPPage from "../../components/auth/otp/VerifyOTPPage";
const VerifyOTP = () => {
    return(
        <>
            <VerifyOTPPage/>
        </>
    );
}
export default VerifyOTP;