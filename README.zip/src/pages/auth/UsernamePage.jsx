import React from "react";
import UsernamePage from "../../components/auth/UsernamePage";

const Username = () => {
    return(
        <>
            <UsernamePage/>
        </>
    )
}
export default Username;