import React from "react";
import SavedProfilePage from "../components/profile/SavedProfilePage";
const SavedProfile = () => {
    return(
        <>
            <SavedProfilePage/>
        </>
    );
}
export default SavedProfile;