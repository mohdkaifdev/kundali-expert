export const walletData = {
  balance: 50.00,
  rechargePacks: [
    { id: 1, amount: 200.00, offer: "Get 25% off" },
    { id: 2, amount: 200.00, offer: "Get 25% off" },
    { id: 3, amount: 200.00, offer: "Get 25% off" }
  ]
}