const consultationData = [
  {
    id: 1,
    blockClass: "consultation_list_block1",
    title: "Get 1-2 Questions Kundali Prediction",
    price: "INR 6018",
    offer: "20% OFF",
    link: "/consultation-detail-1"
  },
  {
    id: 2,
    blockClass: "consultation_list_block2",
    title: "Get 1-2 Questions Kundali Prediction",
    price: "INR 6018",
    offer: "20% OFF",
    link: "/consultation-detail-2"
  },
  {
    id: 3,
    blockClass: "consultation_list_block3",
    title: "Get 1-2 Questions Kundali Prediction",
    price: "INR 6018",
    offer: "20% OFF",
    link: "/consultation-detail-3"
  }
]
export default consultationData