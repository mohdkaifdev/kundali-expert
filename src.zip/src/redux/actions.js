export const updateCart = (payload) => ({ type: 'UPDATE_CART', payload });
export const loginUser = () => ({ type: 'LOGIN_USER' });